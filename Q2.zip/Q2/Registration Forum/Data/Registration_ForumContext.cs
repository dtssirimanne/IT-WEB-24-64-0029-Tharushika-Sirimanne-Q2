﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Registration_Forum.Model1;
using Registration_Forum.Model2;

namespace Registration_Forum.Data
{
    public class Registration_ForumContext : DbContext
    {
        public Registration_ForumContext (DbContextOptions<Registration_ForumContext> options)
            : base(options)
        {
        }

        public DbSet<Registration_Forum.Model1.Student> Student { get; set; } = default!;
        public DbSet<Registration_Forum.Model2.Course> Course { get; set; } = default!;
    }
}
