﻿namespace Registration_Forum.Model2
{
    public class Course

    {
        public int CourseId { get; set; }
        public string Name { get; set; }
        public string LecturerName { get; set; }
    }
}
