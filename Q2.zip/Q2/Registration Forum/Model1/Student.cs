﻿namespace Registration_Forum.Model1
{
    public class Student

    { 
        
        public int StudentId { get; set; } //primary key
        public string  Name{ get; set; }
        
        public string city { get; set; }
        public int CourseId { get; set; }
    }
}
