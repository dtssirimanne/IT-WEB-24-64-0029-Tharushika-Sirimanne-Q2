﻿namespace Registration_Forum.Model1
{
    public class StudentInfo
    {
        public int StudentId { get; set; }
        public int CourseId { get; set; }
        public string  Name{ get; set; }
    }
}
