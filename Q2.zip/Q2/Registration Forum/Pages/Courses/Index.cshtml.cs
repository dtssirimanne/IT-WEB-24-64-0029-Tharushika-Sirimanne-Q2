﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Registration_Forum.Data;
using Registration_Forum.Model2;

namespace Registration_Forum.Pages.Courses
{
    public class IndexModel : PageModel
    {
        private readonly Registration_Forum.Data.Registration_ForumContext _context;

        public IndexModel(Registration_Forum.Data.Registration_ForumContext context)
        {
            _context = context;
        }

        public IList<Course> Course { get;set; } = default!;

        public async Task OnGetAsync()
        {
            Course = await _context.Course.ToListAsync();
        }
    }
}
