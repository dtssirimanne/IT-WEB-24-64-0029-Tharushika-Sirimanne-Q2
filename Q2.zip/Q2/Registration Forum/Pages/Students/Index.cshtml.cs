﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Registration_Forum.Data;
using Registration_Forum.Model1;

namespace Registration_Forum.Pages.Students
{
    public class IndexModel : PageModel
    {
        private readonly Registration_Forum.Data.Registration_ForumContext _context;

        public IndexModel(Registration_Forum.Data.Registration_ForumContext context)
        {
            _context = context;
        }

        public IList<Student> Student { get;set; } = default!;

        public async Task OnGetAsync()
        {
            Student = await _context.Student.ToListAsync();
        }
    }
}
